@include('client.header')

<body>
    @include('client.navbar')
    @include('client.home')

    @include('client.footer')
</body>
@if (session('error'))
    <div class="alert alert-danger text-center">
        {{ session('error') }}
    </div>
@endif

</html>

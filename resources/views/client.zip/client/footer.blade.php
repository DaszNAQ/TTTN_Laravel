 <!-- Footer -->
 <div class="footer mt-5">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <h5>THÔNG TIN LIÊN HỆ</h5>
          <a href="#">Mua hàng: 1900 8922</a>
          <a href="#">Bảo hành: 1900 8174</a>
          <a href="#">Phản ánh dịch vụ: 0364 444 247</a>
          <a href="#">hotro@mobilezone.vn</a>
        </div>
        <div class="col-md-3">
          <h5>CHÍNH SÁCH</h5>
          <a href="#">Mua hàng & thanh toán</a>
          <a href="#">Giao hàng & đổi trả</a>
          <a href="#">Bảo hành</a>
          <a href="#">Bảo mật thông tin</a>
        </div>
        <div class="col-md-3">
          <h5>HỖ TRỢ</h5>
          <a href="#">Hướng dẫn sử dụng</a>
          <a href="#">Câu hỏi thường gặp</a>
          <a href="#">Liên hệ chăm sóc KH</a>
        </div>
        <div class="col-md-3">
          <h5>KẾT NỐI</h5>
          <a href="#">Facebook</a>
          <a href="#">YouTube</a>
          <a href="#">Instagram</a>
          <a href="#">Zalo</a>
        </div>
      </div>
      <div class="text-center mt-4">
        <p>&copy; 2025 MobileZone. All rights reserved.</p>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

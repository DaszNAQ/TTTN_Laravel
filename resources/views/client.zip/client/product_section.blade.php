  <!-- Product Section -->
  <div class="container mt-5">
    <h2 class="mb-4">Điện thoại nổi bật</h2>
    <div class="row">
      <div class="col-md-3">
        <div class="card product-card">
          <img src="https://picsum.photos/300/200?random=4" class="card-img-top" alt="iPhone 15 Pro">
          <div class="card-body">
            <h5 class="card-title">iPhone 15 Pro</h5>
            <p class="card-text">27,990,000 VNĐ</p>
            <a href="#" class="btn btn-sm btn-success">Thêm vào giỏ</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card product-card">
          <img src="https://picsum.photos/300/200?random=5" class="card-img-top" alt="Samsung S24 Ultra">
          <div class="card-body">
            <h5 class="card-title">Samsung S24 Ultra</h5>
            <p class="card-text">25,490,000 VNĐ</p>
            <a href="#" class="btn btn-sm btn-success">Thêm vào giỏ</a>
          </div>
        </div>
      </div>
      <!-- Thêm sản phẩm khác tại đây -->
    </div>
  </div>

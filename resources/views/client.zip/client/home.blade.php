@extends('client.layout')

@section('content')

    @include('client.banner')
@endsection
